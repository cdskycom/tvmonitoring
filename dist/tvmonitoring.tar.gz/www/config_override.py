# -*- coding: utf-8 -*-
'''
Default configurations.
'''

configs = {
	
	'db': {
		'host': '127.0.0.1'
		
	}
}