# -*- coding: utf-8 -*-
'''
Default configurations.
'''

configs = {
	'debug': True,
	'db': {
		'host': '127.0.0.1',
		'port': 3306,
		'user': 'tvmonitoring',
		'password': 'yst@tvmonitoring',
		'db': 'tvmonitoring'
	},
	'session': {
		'secret': 'YstenTV'
	}
}